package com.delivery;

public class ApplicationException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private boolean fatal;

	public ApplicationException(String message) {
		System.out.println(message);
	}

	public ApplicationException(String message, boolean fatal) {
		System.out.println(message);
		this.fatal = fatal;
	}

	public ApplicationException(boolean fatal) {
		this.fatal = fatal;
	}

	public boolean isFatal() {
		return fatal;
	}
}
