package com.delivery;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class CommonIUtil {
	private static final Scanner input = new Scanner(System.in);
	private static DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");

	private CommonIUtil() {

	}

	public static String read(String m) {
		System.out.print(m);
		String result = input.nextLine().trim();

		if (result.equals("Quit"))
			throw new ApplicationException("Thanks", true);

		return result;
	}

	public static int readInt(String m) {
		try {
			return Integer.valueOf(read(m));
		} catch (NumberFormatException e) {
			System.out.println("Enter Integer Number");
			return readInt(m);
		}
	}

	public static LocalDate readDate(String m) {
		try {
			return LocalDate.parse(read(m), df);
		} catch (DateTimeParseException e) {
			showTitle("Please must be enter date with yyyy-mm-dd");
			return readDate(m);
			// return null;
		}
	}

	public static void showTitle(String m) {

		System.out.println();
		showLine(1);
		showMessage(m);
		showLine(1);
		System.out.println();
	}

	public static void showMessage(String m) {
		System.out.println(m);
	}

	public static void showLine(int length) {
		int i = 0;
		while (length > i) {
			System.out.println("============================================");
			i++;
		}
	}
}
