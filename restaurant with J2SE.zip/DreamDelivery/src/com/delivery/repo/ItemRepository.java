package com.delivery.repo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import com.delivery.dto.Category;
import com.delivery.dto.Item;

public class ItemRepository {

	public List<Item> items;
	public List<Category> categories;
	private static ItemRepository itemRepo;
	private Map<String, Category> catMap = new HashMap<>();

	public ItemRepository() {
		items = new ArrayList<>();

		Path file = Paths.get("items.txt");
		try {
			List<String> lines = Files.readAllLines(file);
			for (String line : lines) {
				Item item = new Item();
				Category cat = new Category();
				String[] arr = line.split("\t");
				cat.setName(arr[2]);
				catMap.put(cat.getName(), cat);
				cat.setId(catMap.size());

				item.setId(Integer.valueOf(arr[0]));
				item.setName(arr[1]);
				item.setPrice(Integer.valueOf(arr[3]));
				item.setCategoroy(cat);
				items.add(item);
			}

			categories = new ArrayList<>(catMap.values());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static ItemRepository getInstance() {
		if (Objects.isNull(itemRepo))
			itemRepo = new ItemRepository();
		return itemRepo;
	}

	public List<Category> getCategories() {
		return categories;
	}

	public List<Item> search(int cid) {
		return items.stream().filter(i->i.getCategoroy().getId()==cid).collect(Collectors.toList());
	}

	public Item findById(int id) {
		return items.stream().filter(in -> in.getId() == id).findFirst().orElse(null);
	}
}
