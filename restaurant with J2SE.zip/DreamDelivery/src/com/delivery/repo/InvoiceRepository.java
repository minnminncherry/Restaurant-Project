package com.delivery.repo;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import com.delivery.dto.Invoice;

public class InvoiceRepository {

	public List<Invoice> invoices;
	private static InvoiceRepository invoiceRepo;
	private static int id;
	
	@SuppressWarnings("unchecked")
	public InvoiceRepository() {
		try(ObjectInputStream ois=new ObjectInputStream(new FileInputStream("invoice.txt")))
		{
			id=invoices.stream().mapToInt(i->i.getId()).max().getAsInt();
			invoices=(List<Invoice>) ois.readObject();
			
		}catch(Exception e)
		{
			invoices=new ArrayList<>();
		}
	}
	
	public static InvoiceRepository getInstance()
	{
		if (Objects.isNull(invoiceRepo))
			invoiceRepo = new InvoiceRepository();
		return invoiceRepo;
	}
	
	public void add(Invoice invoice)
	{
		
		try(ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream("invoice.txt")))
		{
			invoice.setId(++id);
			invoices.add(invoice);
			oos.writeObject(invoice);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public Invoice findById(int id) {
		return invoices.stream().filter(in->in.getId()==id).findFirst().orElse(null);
		
	}
	
	public List<Invoice> search(LocalDate from,LocalDate to)
	{
		return invoices.stream().filter(invoice->invoice.getInvoiceDate().compareTo(from)>=0).filter(invoice->invoice.getInvoiceDate().compareTo(to)<=0).collect(Collectors.toList());
	}
	
}
