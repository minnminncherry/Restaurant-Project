package com.delivery.dto;

import java.io.Serializable;

public class Item implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private String name;
	private Category categoroy;
	private int price;
	
	public Item() {
		
	}

	public Item(int id, String name, Category categoroy, int price) {
		super();
		this.id = id;
		this.name = name;
		this.categoroy = categoroy;
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Category getCategoroy() {
		return categoroy;
	}

	public void setCategoroy(Category categoroy) {
		this.categoroy = categoroy;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
	public static String title()
	{
		String str="Item List";
		String str2="----------------------------------------------------------";
		return String.format("%s%n%s%n%-3s%-20s%15s%15s%n%s", str,str2,"ID","Name","Category","Price",str2);
	}
}
