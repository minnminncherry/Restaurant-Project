package com.delivery.dto;

import java.io.Serializable;

public class Category implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String name;

	public Category() {

	}

	public Category(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static String title()
	{
		String str="Categories";
		String str2="-------------------";
		return String.format("%s%n%s%n%-5s%-10s%n%s",str,str2,"ID","Category",str2);
	}
}
