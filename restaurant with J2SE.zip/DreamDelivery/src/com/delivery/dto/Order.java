package com.delivery.dto;

import java.io.Serializable;

public class Order implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Item item;
	private Invoice invoice;
	private int count;
	public Order() {
		
	}

	public Order(Item item, Invoice invoice) {
		super();
		this.item = item;
		this.invoice = invoice;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public Invoice getInvoice() {
		return invoice;
	}

	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
	public static String title()
	{
		String line="----------------------------------------------------------------------";
		return String.format("%s%n%-5s%-15s%-15s%13s%12s%n%s",line,"Id","Invoice Date","Customer","Phone","Total",line);
	}
}
