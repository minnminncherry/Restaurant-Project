package com.delivery.dto;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Invoice implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private String customer;
	private String phone;
	private LocalDate invoiceDate;
	private List<Order> orders;
	private int total;
	
	public Invoice() {
		orders=new ArrayList<>();
	}
	
	public Invoice(int id, String customer, String phone, LocalDate invoiceDate, List<Order> orders, int total) {
		super();
		this.id = id;
		this.customer = customer;
		this.phone = phone;
		this.invoiceDate = invoiceDate;
		this.orders = orders;
		this.total = total;
	}
	
	public void addOrder(Order o)
	{
		orders.add(o);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public LocalDate getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(LocalDate invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}
	
	public static String title()
	{
		String line="----------------------------------------------------------------------";
		return String.format("%s%n%-5s%-20s%12s%10s%12s%n%s",line,"ID","Name","Price","Count","Total",line );
	}
}
