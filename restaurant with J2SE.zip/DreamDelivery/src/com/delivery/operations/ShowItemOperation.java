package com.delivery.operations;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.delivery.CommonIUtil;
import com.delivery.dto.Category;
import com.delivery.dto.Item;
import com.delivery.repo.ItemRepository;

public class ShowItemOperation extends BaseOperation {
	private ItemRepository items;

	public ShowItemOperation() {
		items = ItemRepository.getInstance();
	}

	@Override
	public void doOperation() {
		CommonIUtil.showTitle(">Show Item");
		int choose = showCategory();
		showItem(choose);

	}

	public int showItem(int choose) {

		do {
			List<Item> itemlist = new ArrayList<>(items.search(choose));
			if (itemlist.size() == 0) {
				choose = CommonIUtil.readInt("Enter right Category ID : ");
				continue;
			}
			System.out.println(Item.title());
			for (Item item : itemlist) {
				System.out.printf("%-3d%-20s%15s%15d%n", item.getId(), item.getName(), item.getCategoroy().getName(),
						item.getPrice());
			}
			break;
		} while (true);
		return choose;
	}

	public int showCategory() {

		List<Category> catlist = new ArrayList<>(items.getCategories());
		System.out.println(Category.title());
		Collections.sort(catlist, (c1, c2) -> c1.getId().compareTo(c2.getId()));
		for (Category cat : catlist) {
			System.out.printf("%-5s%-10s%n", cat.getId(), cat.getName());
		}
		System.out.println();
		int choose = CommonIUtil.readInt("Select One : ");
		return choose;
	}

}
