package com.delivery.operations;

import java.time.LocalDate;
import java.util.List;

import com.delivery.CommonIUtil;
import com.delivery.dto.Invoice;
import com.delivery.dto.Order;
import com.delivery.repo.InvoiceRepository;

public class SaleReportOperation extends BaseOperation{
	private InvoiceRepository invoice;
	public SaleReportOperation() {
		invoice=InvoiceRepository.getInstance();
	}
	@Override
	public void doOperation() {
		CommonIUtil.showTitle(">Sale Report");
		LocalDate from=CommonIUtil.readDate("Date From (yyyy-mm-dd) : ");
		LocalDate to=CommonIUtil.readDate("Date to (yyyy-mm-dd) : ");
		List<Invoice> search = invoice.search(from, to);
		System.out.println(Order.title());
		for(Invoice in:search)
		{
			System.out.printf("%-5d%-15s%-15s%13s%12d%n",in.getId(),in.getInvoiceDate().toString(),in.getCustomer(),in.getPhone(),in.getTotal());
		}
	}

}
