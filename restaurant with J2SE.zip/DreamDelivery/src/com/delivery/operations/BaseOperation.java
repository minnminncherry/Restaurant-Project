package com.delivery.operations;

public abstract class BaseOperation {

	public BaseOperation() {
		
	}
	
	public void start()
	{
			doOperation();
	}
	public abstract void doOperation();
	
}
