package com.delivery.operations;

import java.time.LocalDate;

import com.delivery.CommonIUtil;
import com.delivery.dto.Invoice;
import com.delivery.dto.Item;
import com.delivery.dto.Order;
import com.delivery.repo.InvoiceRepository;
import com.delivery.repo.ItemRepository;

public class TakeOrderOperation extends BaseOperation {

	private ItemRepository items;
	InvoiceRepository invoice;
	ShowItemOperation showItem;

	public TakeOrderOperation() {
		items = ItemRepository.getInstance();
		invoice = InvoiceRepository.getInstance();
		showItem = new ShowItemOperation();
	}

	@Override
	public void doOperation() {
		Invoice newInvoice = new Invoice();
		CommonIUtil.showTitle(">Take Order");
		String name = CommonIUtil.read("Customer : ");
		String phone = CommonIUtil.read("Phone : ");

		int total = 0;
		boolean same = true;
		int choose = 0;
		try {
			do {
				
				if (!same) {
					String catSame = CommonIUtil.read("Same Category(y/n)? : ");
					if (!catSame.equalsIgnoreCase("y")) {
						choose = showItem.showCategory();
						choose=showItem.showItem(choose);
					} else {
						choose=showItem.showItem(choose);
					}
				} else {
					choose = showItem.showCategory();
					choose=showItem.showItem(choose);
				}
				Order order = new Order();
				System.out.println();
				int select = CommonIUtil.readInt("Select One : ");
				int count = CommonIUtil.readInt("Count : ");
				order.setCount(count);
				Item selectItem = items.findById(select);
				total += selectItem.getPrice() * count;
				order.setItem(selectItem);
				newInvoice.addOrder(order);
				same = false;
			} while ("y".equalsIgnoreCase(CommonIUtil.read("Need More(y/n)? : ")));
		
			newInvoice.setCustomer(name);
			newInvoice.setInvoiceDate(LocalDate.now());
			newInvoice.setPhone(phone);
			newInvoice.setTotal(total);
			invoice.add(newInvoice);
		}
		catch(Exception e)
		{
			System.out.println("Invalid Item ID");
		}
	}

}
