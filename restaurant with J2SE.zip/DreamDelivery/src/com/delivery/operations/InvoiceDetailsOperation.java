package com.delivery.operations;

import java.util.List;

import com.delivery.ApplicationException;
import com.delivery.CommonIUtil;
import com.delivery.dto.Invoice;
import com.delivery.dto.Order;
import com.delivery.repo.InvoiceRepository;

public class InvoiceDetailsOperation extends BaseOperation {
	InvoiceRepository invoice;
	int count;
	public InvoiceDetailsOperation() {
		invoice = InvoiceRepository.getInstance();
		CommonIUtil.showTitle(">Invoice Details");
	}
	@Override
	public void doOperation() throws ApplicationException {
		
		try {
			if(count>=3)
			{
				throw new ApplicationException("Wrong Invoice Id more than three times",true);
			}
			int id = CommonIUtil.readInt("Invoice ID : ");
			Invoice find = invoice.findById(id);
			System.out.println();
			System.out.println("Invoice ID\t: " + find.getId());
			System.out.println("Customer\t: " + find.getCustomer());
			System.out.println("Phone\t: " + find.getPhone());
			System.out.println("Total\t: " + find.getTotal());
			System.out.println("\nOrder Details");

			int i = 1;

			List<Order> orders = find.getOrders();
			System.out.println(Invoice.title());
			for (Order o : orders) {
				System.out.printf("%-5d%-20s%12s%10s%12s%n", i++, o.getItem().getName(), o.getItem().getPrice(),
						o.getCount(), o.getItem().getPrice() * o.getCount());
			
			}
		} catch (NullPointerException e) {		
			count++;
			System.out.println("Wrong ID.Enter right ID");
			doOperation();
		}

	}
}
