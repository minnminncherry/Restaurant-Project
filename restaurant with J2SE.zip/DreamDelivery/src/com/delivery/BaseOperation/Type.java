package com.delivery.BaseOperation;

import com.delivery.CommonIUtil;
import com.delivery.operations.BaseOperation;
import com.delivery.operations.InvoiceDetailsOperation;
import com.delivery.operations.SaleReportOperation;
import com.delivery.operations.ShowItemOperation;
import com.delivery.operations.TakeOrderOperation;

public enum Type {
	ShowItems (1,"ShowItem"){
		@Override
		public BaseOperation getOperation() {
			// TODO Auto-generated method stub
			return new ShowItemOperation();
		}
	},TakeOrder (2,"TakeOrder"){
		@Override
		public BaseOperation getOperation() {
			// TODO Auto-generated method stub
			return new TakeOrderOperation();
		}
	},SaleReports (3,"SaleReport"){
		@Override
		public BaseOperation getOperation() {
			// TODO Auto-generated method stub
			return new SaleReportOperation();
		}
	},InvoiceDetails (4,"InvoiceDetails"){
		@Override
		public BaseOperation getOperation() {
			// TODO Auto-generated method stub
			return new InvoiceDetailsOperation();
		}
	};
	private int id;
	private String name;
	
	private Type(int id, String name) {
		this.id = id;
		this.name = name;
	}

	@Override
	public String toString() {
		return String.format("%-7d%-15s", id,name);
	}
	

	public abstract BaseOperation getOperation();
	
	public static Type getOperationType()
	{
		CommonIUtil.showTitle("Operation");

		System.out.printf("%-7s%-15s%n", "ID", "Operation");
		System.out.println("-----------------------------");
		for (Type type : Type.values()) {
			System.out.println(type);
		}
		System.out.println();
		int choose = CommonIUtil.readInt("Select One : ");
		System.out.println();
		for (Type type : Type.values()) {
			if(type.id==choose)
			{
				return type;
			}
		}
		return null;
		
	}
	
}
