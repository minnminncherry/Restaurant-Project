package com.delivery;

import com.delivery.BaseOperation.Type;

public class Application {

	public static void main(String[] args) throws ApplicationException {
		CommonIUtil.showTitle("Welcome Dream Delivery");
		for (;;) {
			try {
			Type type = Type.getOperationType();
			type.getOperation().start();
			}
			catch(ApplicationException e)
			{
				if(e.isFatal())
					break;
			}
			catch(NullPointerException e)
			{
				continue;
			}
		}
	}
}
